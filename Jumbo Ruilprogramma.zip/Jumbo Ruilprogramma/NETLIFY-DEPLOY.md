# HubConnect op Netlify zetten

Op Netlify draait de **voorkant** (statisch) + de **backend als serverless functions** (Node + PostgreSQL).
De Java-server is dan niet nodig. De app werkt zo overal, op elk apparaat, ook zonder dat jouw laptop aanstaat.

Belangrijk om te snappen: een browser kan **niet** rechtstreeks met PostgreSQL praten. De functies
`netlify/functions/state.mjs` en `version.mjs` zijn de tussenlaag die met de database verbindt.

## Wat al klaarstaat (in deze map)
- `netlify.toml` — stuurt `/api/state` en `/api/version` naar de functies.
- `package.json` — installeert de Postgres-driver `pg`.
- `netlify/functions/state.mjs` — leest/schrijft de hele staat in de tabellen.
- `netlify/functions/version.mjs` — lichte poll-endpoint voor realtime (elke ~3s).

De **wachtwoorden staan NIET in deze map** — die komen als omgevingsvariabele op Netlify (zie stap 3).

## Stappen
1. **Zet deze map in een Git-repo** (GitHub/GitLab). Publish-map = deze map (`Jumbo Ruilprogramma`).
2. **Netlify → Add new site → Import from Git**, kies de repo. Build command leeg laten; publish dir = de map met `index.html`.
3. **Environment variables** (Site settings → Environment variables) — voeg toe:
   - `DATABASE_URL` = `postgresql://postgres:Slimstekkie1234@51.145.115.118:5432/Jumbo`
4. **Deploy**. Open daarna de Netlify-URL (bijv. `https://hubconnect.netlify.app`).
5. Inloggen als admin (`marlon@admin.com` / `Admin!1`), accounts aanmaken — klaar.

(Alternatief zonder Git: Netlify CLI → `netlify deploy --prod` vanuit deze map. Vereist wel een apparaat met de CLI.)

## Realtime
Op Netlify gebeurt realtime via **polling**: elk apparaat checkt elke ~3 seconden of er iets gewijzigd is
en ververst dan. Updates zijn dus binnen een paar seconden zichtbaar (niet de directe push van de
Java-versie, maar prima in gebruik).

## Aandachtspunten
- De database moet **van buitenaf bereikbaar** zijn (dat is hij nu, want hij staat op een publiek IP).
- **Beveiliging**: dat publieke IP + wachtwoord is een risico. Wijzig het wachtwoord en beperk toegang
  (firewall/Netlify-uitgaande IP's) zodra je kunt; pas dan `DATABASE_URL` op Netlify aan.
- Werkt op elk apparaat met de Netlify-URL; geen laptop van jou nodig nadat het gedeployed is.
- Dezelfde tabellen worden gebruikt als de Java-server, dus je kunt later kiezen welke backend je draait
  (Netlify-functions óf de Java-server op bijv. Render) — niet allebei tegelijk schrijven.
