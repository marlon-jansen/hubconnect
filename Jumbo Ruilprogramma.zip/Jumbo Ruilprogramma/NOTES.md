# Ruilhub / HubPortaal — roadmap & openstaande wensen

Bijgewerkt: 29-06-2026. Dit bestand verzamelt wat nog gebouwd moet worden.

## Notitie voor later
- **Podium / leaderboard**: top 3 (1-2-3) van wie de meeste shifts heeft overgenomen, met een podium-visual.
  (Idee uit schets gebruiker.)

## Al gedaan (deze ronde)
- Login: terugknop rechtsboven; "hr-" vooringevuld.
- Header: logo prominenter (witte badge).
- Homepage: tagline-chip weg, nettere shiftkaart-tekst ("Shift van X").
- Statistieken: overgenomen = groen ↑, weggegeven = rood ↓; aparte secties Shifts/Taken.
- Takenlijst alfabetisch; taken hebben nu een **type** (bezorger-taak / senior-taak), Binnendienst = senior-taak en toewijsbaar; senior mag bezorger-taken ook.
- Beheren: N2 = losse toggle (iedereen heeft diesel), niemand wijzigt eigen functie.
- Bus-keuze: Volkswagen/diesel en N2/elektrisch.
- AM = zonsopkomst-gradient + fellere zon, PM = nacht-gradient + maan.
- Backup-knop duidelijke rand. Davy Peters = locatie-manager.

## RuilHub afmaken — GEDAAN
- [x] Eigen **datumkiezer** (kalender-popover).
- [x] Ruilbord **per dag** met AM/PM-secties + **"Alles"**-weergave (shifts/taken/oproepen/back-up samen).
- [x] **FCFS-melding vóór overnemen**: keuze "Neem de eerste shift" / "Toch deze overnemen".
- [x] Optionele **reden** bij aanbieden (vaste lijst) → badge op de kaart.
- [x] **Historie per dag** gegroepeerd, filter incl. oproepen.
- [x] **Oproep** ("shift gezocht").
- [x] **Back-up beide kanten** (rijden / rit weggeven) met ritdetails voor de beoordelaar.
- [x] Klik op een naam → **medewerkerdetail** (stats + taken/functie bewerken voor leiding).
- [x] **Super-admin** (admin@jumbo.com): kan alles, verborgen uit lijsten, acties niet gelogd.

Reden-lijst (pas aan indien gewenst): Ziekte, Uitvaart / begrafenis, Medische afspraak, Familieomstandigheden, Vakantie, Studie / school, Persoonlijke reden.

## Takenplanning — GEDAAN
- [x] Weekrooster (medewerkers × dagen, AM blauw / PM oranje, taak + tijd per vak), week-navigatie, rijen toevoegen/verwijderen.
- [x] **Downloaden als afbeelding** (PNG via canvas) voor de groepsapp.

## Operationele modules (prototype) — GEDAAN
- [x] **Schadecontrole**: bussen importeren (naam; busnr; kenteken) of toevoegen; per bus afvinken schade/tolkrol/kabels/doekjes; voortgangsbalk.
- [x] **Kwaliteit**: tellers trolleys 4-/5-laags + emballage; vak 1–18 pendel-tellers.
- [x] **LC**: vak 1–40 koppelen aan bus + rit + type (diesel/N2) + ZE + geladen-vinkje; importeren ochtendkoppeling; voortgangsbalk.
- [x] **Live tussen tabbladen** via storage-events (echte realtime tussen telefoons vraagt nog een server).

## Operationeel v2 + dashboard — GEDAAN
- [x] **Senior-dashboard** (tegel, senior+): realtime ringen voor schade- en laadvoortgang, trolley-voorraad, emballage-totaal, en dock-klaarzetlijst.
- [x] **Schadecontrole**: kolom-import (aparte velden busnr/kenteken/naam), dock-toewijzing door senior (16/17/18/21/22/23) zichtbaar voor controleur.
- [x] **Kwaliteit**: trolley-voorraad op de hub (door LC bijgewerkt, door kwaliteit te corrigeren in eindronde); emballage per vak met **14 trolleys** (krat-invoer per trolley, automatische optelling) — zoals de tekening.
- [x] **LC**: senior stelt vooraf het **aantal te laden vakken** in en kan alvast invullen; LC vinkt af; **trolleys verzenden** (binnen/terug, 4/5-laags) past de voorraad live aan; kolom-import.
- [x] CSS opgefrist (dashboard-ringen, emballage-rek, kolom-import).

## HubConnect-ronde — GEDAAN
- [x] Platform hernoemd naar **HubConnect**; landing algemener/professioneler (alle modules i.p.v. alleen ruilen).
- [x] Operationele data **per datum + AM/PM** (shift-bar in elke module + dashboard). **Zondag = alleen AM**, ook afgedwongen in RuilHub (aanbieden/oproep/back-up; PM verborgen bij zondag).
- [x] **Setup via dashboard** (binnendienst/senior+): schade-import + docks, LC aantal vakken + bus/rit/type/ZE + import, en **dienst-toewijzing** (wie doet schade/LC/kwaliteit deze shift → bepaalt toegang).
- [x] Schade-module: **alleen afvinken**. LC-module: geladen afvinken + (PM) busnummers + **pendels** (4/5-laags symbolen, groene ↓ binnen / rode ↑ retour). Kwaliteit-module: **alleen emballage per vak**.
- [x] Emballage **per vak** zichtbaar op dashboard (geen totaal). Alle uitleg-tekstjes verwijderd.

## Nog open / ideeën
- [ ] **Podium / leaderboard** (top 3 meeste shifts overgenomen).
- [ ] Echte server/database voor realtime tussen apparaten (nu localStorage-prototype).
- [ ] Reden-lijst desgewenst aanpassen.
- [ ] Kwaliteit: exacte telkaart uit de papieren versie (schets) verfijnen indien gewenst.

## Nog te doen — Hub-portaal (nieuwe modules)
Na inloggen een **keuzemenu** (portaal). Bezorger ziet alleen **RuilHub**. Senior+ ziet ook:

### Takenplanning
- Weekrooster maken (medewerkers × dagen, AM/PM, taak), zoals de huidige Excel.
- **Downloadbaar als afbeelding** voor de groepsapp.
- Geen server strikt nodig (1 maker), maar delen = handmatig downloaden/posten.

### Schadecontrole  *(realtime → server nodig voor echt gebruik)*
- Import vanuit Excel-planning: bezorgernaam + busnummer + kenteken.
- Per bus afvinken: schadecontrole gedaan / tolkrol / kabeltjes / doekjes.
- Alleen door mensen met schadecontrole-bevoegdheid.
- Binnendienst ziet voortgang **realtime**.

### Kwaliteit  *(realtime → server nodig)*
- Tellen van retour kratten/emballage (papier vervangen).
- Trolley-teller: 4-laags en 5-laags.
- Vak 1 t/m 18 (pendels) — binnendienst ziet realtime.

### LC (Laadcoördinator)  *(realtime → server nodig)*
- Trolley-telling + laadproces bussen.
- Laadvakken 1 t/m 40 → koppeling **vak ↔ busnummer ↔ ritnummer**.
- Ochtend: importeren (al gekoppeld). Middag: LC kiest welk vak in welke bus.
- Niet alle vakken vol; 2e ritten mogelijk; ZE-bussen markeren; elektrische bussen door bezorger zelf geladen (busnummer wel bekend, vakken vooraf bekend).
- Binnendienst ziet laadvoortgang **realtime**.

## Architectuur-aandachtspunt
localStorage is **per apparaat**. De operationele modules (schadecontrole, kwaliteit, LC) hebben
**live updates tussen meerdere telefoons tegelijk** nodig — dat kan alleen met een **server + database**
(bijv. Node + SQLite/Postgres, of een dienst als Firebase/Supabase voor realtime).
Binnen één browser/tabs kan ik "realtime" wel simuleren als demo.
