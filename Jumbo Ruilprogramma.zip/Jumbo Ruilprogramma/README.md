# Ruilhub — Jumbo Bezorgservice

Lokaal prototype om shifts, taken en back-up te ruilen binnen een hub, als vervanging van de ruil-WhatsappGroep.
Alle data staat in de browser (`localStorage`) — prototype voor één apparaat. Voor echt gedeeld gebruik tussen
meerdere telefoons is later een online versie met server nodig.

## Starten
- Via Claude Code preview: server **ruilprogramma** (poort **8210**).
- Of handmatig in deze map: `py -m http.server 8210` en open `http://localhost:8210`.

De app opent op een interactieve voorpagina; klik **Inloggen** om in te loggen (met terugknop).

## Accounts
- Inloggen met het e-mailadres dat bij het account is ingevuld (vrij te kiezen, geen vast formaat).
- **Geen zelfregistratie.** Teamleider of hoger maakt een account aan (Beheren → Nieuwe medewerker) en geeft
  de medewerker een **eenmalige code**. Bij de eerste keer inloggen stelt de medewerker zelf een wachtwoord in.
- Demo-accounts (wachtwoord `demo123`) staan op het inlogscherm onder "Demo-accounts".
- Wachtwoord wijzigen: hover over je avatar (rechtsboven) → tandwiel → profiel.

## Rollen (oplopend)
Aankomend bezorger → Bezorger → Senior bezorger → Teamleider → Locatie-manager.
Aankomend en Bezorger hebben dezelfde rechten (proeftijd-onderscheid).

## Belangrijkste regels
- Ruilen kan **alleen binnen de eigen hub**.
- **N2** (elektrische bus): wie geen N2-bevoegdheid heeft ziet N2-shifts wel, maar kan ze niet overnemen.
- **Taken** (LC, Schadecontrole, Kwaliteit, Inname, Laden): alleen wie de taak mag uitvoeren kan 'm overnemen.
  - **Binnendienst**: vaste senior-taak; alleen zichtbaar voor senior en hoger (onderlinge wissels onzichtbaar voor bezorgers).
  - **JBT-training**: taak tijdens de rit, alleen voor medewerkers met de **JBT-trainer**-toevoeging.
  - **Opleiding** en **Back-up** zijn geen taken.
- **Back-up**: sta je op back-up en wil je rijden? Plaats een verzoek; een collega die zelf op back-up wil geeft zijn rit.
- Starttijd / N2 / taak vul je pas in als **de shifts bekend zijn** (AM volgende ochtend ~17:00, PM diezelfde dag ~09:00).
  Starttijdvenster: **AM 05:00–15:00, PM 13:00–23:00**.
- **Wie eerst aanbiedt, gaat voor** (FCFS) bij shifts zonder starttijd. Neemt iemand een later geplaatste shift over
  terwijl een eerdere nog open staat, dan krijgt de beoordelaar een waarschuwing. Publicatiedatum/-tijd staat op elke kaart.
- Een ruiling staat **In afwachting** tot goedkeuring; afkeuren zet 'm terug op het bord.

## Wie mag wat
- **Goedkeuren**: teamleider+ altijd; senior keurt taken/back-up en shiftwissels die zijn geplaatst toen de shifts al bekend waren.
- **Statistieken** (per medewerker, sorteerbaar): teamleider+.
- **Historie / logboek** (met zoeken en filteren): senior+.
- **Beheren**: senior+ kan bekijken; teamleider+ wijzigt N2, taken, JBT en maakt accounts aan;
  **functies** toewijzen en **hubs** beheren kan alleen de locatie-manager.

## Logo
De header gebruikt een Jumbo-stijl wordmark in SVG. Wil je een eigen bestand gebruiken, zet dan `logo.png`
in deze map; dan koppel ik die in plaats van de SVG.

## Bestanden
- `index.html` — opbouw
- `styles.css` — huisstijl
- `js/store.js` — datalaag, rollen, rechten (localStorage)
- `js/ui.js` — alle schermen
