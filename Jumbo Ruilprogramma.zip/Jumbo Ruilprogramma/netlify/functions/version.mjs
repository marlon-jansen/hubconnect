import pkg from "pg";
const { Client } = pkg;

// Lichte poll-endpoint: geeft het huidige revisienummer terug.
export async function handler() {
  const headers = { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" };
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await client.connect();
    let v = 0;
    try { const r = await client.query("SELECT v FROM meta WHERE k='rev'"); if (r.rows[0]) v = parseInt(r.rows[0].v, 10); } catch (_) {}
    return { statusCode: 200, headers, body: JSON.stringify({ version: v }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: String(e.message || e) }) };
  } finally { try { await client.end(); } catch (_) {} }
}
