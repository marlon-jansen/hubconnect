import pkg from "pg";
const { Client } = pkg;

const DDL = [
  "CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)",
  "CREATE TABLE IF NOT EXISTS hubs (id TEXT PRIMARY KEY, naam TEXT)",
  "CREATE TABLE IF NOT EXISTS task_catalog (naam TEXT PRIMARY KEY, type TEXT, ord INT)",
  "CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, personeelsnummer TEXT, email TEXT, voornaam TEXT, achternaam TEXT, pass TEXT, otp TEXT, must_set_password BOOLEAN, rol TEXT, n2 BOOLEAN, jbt_trainer BOOLEAN, hub_id TEXT, taken JSONB, stats JSONB, hidden BOOLEAN, created_at TEXT)",
  "CREATE TABLE IF NOT EXISTS shifts (id TEXT PRIMARY KEY, aanbieder_id TEXT, hub_id TEXT, datum TEXT, dagdeel TEXT, shifts_bekend BOOLEAN, starttijd TEXT, bus_type TEXT, taak TEXT, status TEXT, overnemer_id TEXT, besluit_door_id TEXT, besluit_op TEXT, reden TEXT, fifo_warning BOOLEAN, fifo_skipped_by TEXT, fifo_skipped_at TEXT, seq BIGINT, aanbied_reden TEXT, created_at TEXT)",
  "CREATE TABLE IF NOT EXISTS task_offers (id TEXT PRIMARY KEY, aanbieder_id TEXT, hub_id TEXT, datum TEXT, dagdeel TEXT, taak TEXT, starttijd TEXT, aanbied_reden TEXT, status TEXT, overnemer_id TEXT, besluit_door_id TEXT, besluit_op TEXT, reden TEXT, created_at TEXT)",
  "CREATE TABLE IF NOT EXISTS backups (id TEXT PRIMARY KEY, aanbieder_id TEXT, hub_id TEXT, datum TEXT, dagdeel TEXT, direction TEXT, toelichting TEXT, rit_omschrijving TEXT, rit_tijd TEXT, status TEXT, overnemer_id TEXT, besluit_door_id TEXT, besluit_op TEXT, reden TEXT, created_at TEXT)",
  "CREATE TABLE IF NOT EXISTS callouts (id TEXT PRIMARY KEY, aanbieder_id TEXT, hub_id TEXT, datum TEXT, dagdeel TEXT, toelichting TEXT, status TEXT, overnemer_id TEXT, besluit_door_id TEXT, besluit_op TEXT, reden TEXT, created_at TEXT)",
  "CREATE TABLE IF NOT EXISTS logs (id TEXT PRIMARY KEY, type TEXT, actie TEXT, ref_id TEXT, door_id TEXT, aanbieder_id TEXT, overnemer_id TEXT, hub_id TEXT, details JSONB, reden TEXT, ts TEXT)",
  "CREATE TABLE IF NOT EXISTS plannings (id TEXT PRIMARY KEY, hub_id TEXT, week_start TEXT, created_at TEXT, rows JSONB, cells JSONB)",
  "CREATE TABLE IF NOT EXISTS schade (hub_id TEXT, datum TEXT, dagdeel TEXT, buses JSONB, steekproeven JSONB, PRIMARY KEY (hub_id, datum, dagdeel))",
  "CREATE TABLE IF NOT EXISTS kwaliteit (hub_id TEXT, datum TEXT, dagdeel TEXT, emballage JSONB, soort JSONB, PRIMARY KEY (hub_id, datum, dagdeel))",
  "CREATE TABLE IF NOT EXISTS lc (hub_id TEXT, datum TEXT, dagdeel TEXT, aantal INT, vakken JSONB, PRIMARY KEY (hub_id, datum, dagdeel))",
  "CREATE TABLE IF NOT EXISTS trolley (hub_id TEXT, datum TEXT, dagdeel TEXT, stock4 INT, stock5 INT, pendels JSONB, PRIMARY KEY (hub_id, datum, dagdeel))",
  "CREATE TABLE IF NOT EXISTS diensten (hub_id TEXT, datum TEXT, dagdeel TEXT, schadecontrole JSONB, lc JSONB, kwaliteit JSONB, PRIMARY KEY (hub_id, datum, dagdeel))"
];

async function ensureSchema(c) { for (const q of DDL) await c.query(q); }
const key = (r) => r.hub_id + "|" + r.datum + "|" + r.dagdeel;
const S = (v) => (v === undefined ? null : v);                 // string of null
const B = (v) => !!v;                                          // boolean
const N = (v) => (v === undefined || v === null || v === "" ? null : Number(v)); // getal of null
const I = (v) => (v === undefined || v === null || v === "" ? 0 : Number(v));    // int (default 0)
const J = (v, def) => (v === undefined || v === null ? def : JSON.stringify(v)); // jsonb-tekst

async function buildState(c) {
  const root = {};
  root.hubs = (await c.query("SELECT id,naam FROM hubs ORDER BY naam")).rows.map((r) => ({ id: r.id, naam: r.naam }));
  const cat = await c.query("SELECT naam,type FROM task_catalog ORDER BY ord");
  root.taskCatalog = cat.rows.map((r) => r.naam);
  root.taskTypes = {}; cat.rows.forEach((r) => { root.taskTypes[r.naam] = r.type; });
  root.users = (await c.query("SELECT * FROM users")).rows.map((r) => {
    const o = {
      id: r.id, personeelsnummer: r.personeelsnummer, email: r.email, voornaam: r.voornaam, achternaam: r.achternaam,
      pass: r.pass, otp: r.otp, mustSetPassword: !!r.must_set_password, rol: r.rol, n2: !!r.n2, jbtTrainer: !!r.jbt_trainer,
      hubId: r.hub_id, taken: r.taken || [], stats: r.stats || {}, createdAt: r.created_at
    };
    if (r.hidden) o.hidden = true;
    return o;
  });
  const mapRow = (r, cols) => { const o = {}; for (const [col, kk, t] of cols) { const v = r[col]; o[kk] = t === "b" ? !!v : t === "n" ? (v == null ? null : Number(v)) : (v == null ? null : v); } return o; };
  root.shifts = (await c.query("SELECT * FROM shifts")).rows.map((r) => mapRow(r, [["id","id"],["aanbieder_id","aanbiederId"],["hub_id","hubId"],["datum","datum"],["dagdeel","dagdeel"],["shifts_bekend","shiftsBekend","b"],["starttijd","starttijd"],["bus_type","busType"],["taak","taak"],["status","status"],["overnemer_id","overnemerId"],["besluit_door_id","besluitDoorId"],["besluit_op","besluitOp"],["reden","reden"],["fifo_warning","fifoWarning","b"],["fifo_skipped_by","fifoSkippedBy"],["fifo_skipped_at","fifoSkippedAt"],["seq","seq","n"],["aanbied_reden","aanbiedReden"],["created_at","createdAt"]]));
  root.taskOffers = (await c.query("SELECT * FROM task_offers")).rows.map((r) => mapRow(r, [["id","id"],["aanbieder_id","aanbiederId"],["hub_id","hubId"],["datum","datum"],["dagdeel","dagdeel"],["taak","taak"],["starttijd","starttijd"],["aanbied_reden","aanbiedReden"],["status","status"],["overnemer_id","overnemerId"],["besluit_door_id","besluitDoorId"],["besluit_op","besluitOp"],["reden","reden"],["created_at","createdAt"]]));
  root.backups = (await c.query("SELECT * FROM backups")).rows.map((r) => mapRow(r, [["id","id"],["aanbieder_id","aanbiederId"],["hub_id","hubId"],["datum","datum"],["dagdeel","dagdeel"],["direction","direction"],["toelichting","toelichting"],["rit_omschrijving","ritOmschrijving"],["rit_tijd","ritTijd"],["status","status"],["overnemer_id","overnemerId"],["besluit_door_id","besluitDoorId"],["besluit_op","besluitOp"],["reden","reden"],["created_at","createdAt"]]));
  root.callouts = (await c.query("SELECT * FROM callouts")).rows.map((r) => mapRow(r, [["id","id"],["aanbieder_id","aanbiederId"],["hub_id","hubId"],["datum","datum"],["dagdeel","dagdeel"],["toelichting","toelichting"],["status","status"],["overnemer_id","overnemerId"],["besluit_door_id","besluitDoorId"],["besluit_op","besluitOp"],["reden","reden"],["created_at","createdAt"]]));
  root.logs = (await c.query("SELECT * FROM logs ORDER BY ts DESC")).rows.map((r) => ({ id: r.id, type: r.type, actie: r.actie, refId: r.ref_id, doorId: r.door_id, aanbiederId: r.aanbieder_id, overnemerId: r.overnemer_id, hubId: r.hub_id, details: r.details || {}, reden: r.reden, timestamp: r.ts }));
  root.plannings = (await c.query("SELECT * FROM plannings")).rows.map((r) => ({ id: r.id, hubId: r.hub_id, weekStart: r.week_start, createdAt: r.created_at, rows: r.rows || [], cells: r.cells || {} }));
  root.schade = {}; for (const r of (await c.query("SELECT * FROM schade")).rows) root.schade[key(r)] = { buses: r.buses || [], steekproeven: r.steekproeven || [] };
  root.kwaliteit = {}; for (const r of (await c.query("SELECT * FROM kwaliteit")).rows) root.kwaliteit[key(r)] = { emballage: r.emballage || {}, soort: r.soort || {} };
  root.lc = {}; for (const r of (await c.query("SELECT * FROM lc")).rows) root.lc[key(r)] = { aantal: r.aantal || 0, vakken: r.vakken || [] };
  root.trolley = {}; for (const r of (await c.query("SELECT * FROM trolley")).rows) root.trolley[key(r)] = { stock4: r.stock4 || 0, stock5: r.stock5 || 0, pendels: r.pendels || [] };
  root.diensten = {}; for (const r of (await c.query("SELECT * FROM diensten")).rows) root.diensten[key(r)] = { schadecontrole: r.schadecontrole || [], lc: r.lc || [], kwaliteit: r.kwaliteit || [] };
  const meta = {}; for (const r of (await c.query("SELECT k,v FROM meta")).rows) meta[r.k] = r.v;
  if (meta._seq != null) root._seq = Number(meta._seq);
  if (meta.appversion != null) root.version = Number(meta.appversion);
  return root;
}

async function saveState(c, root) {
  await c.query("BEGIN");
  try {
    await c.query("SELECT pg_advisory_xact_lock(987654321)"); // serialiseer schrijvers
    for (const t of ["hubs","task_catalog","users","shifts","task_offers","backups","callouts","logs","plannings","schade","kwaliteit","lc","trolley","diensten"]) await c.query("DELETE FROM " + t);
    for (const o of root.hubs || []) await c.query("INSERT INTO hubs (id,naam) VALUES ($1,$2)", [S(o.id), S(o.naam)]);
    const types = root.taskTypes || {};
    for (let i = 0; i < (root.taskCatalog || []).length; i++) { const naam = root.taskCatalog[i]; await c.query("INSERT INTO task_catalog (naam,type,ord) VALUES ($1,$2,$3)", [naam, types[naam] || "bezorger", i]); }
    for (const o of root.users || []) await c.query(
      "INSERT INTO users (id,personeelsnummer,email,voornaam,achternaam,pass,otp,must_set_password,rol,n2,jbt_trainer,hub_id,taken,stats,hidden,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::jsonb,$14::jsonb,$15,$16)",
      [S(o.id),S(o.personeelsnummer),S(o.email),S(o.voornaam),S(o.achternaam),S(o.pass),S(o.otp),B(o.mustSetPassword),S(o.rol),B(o.n2),B(o.jbtTrainer),S(o.hubId),J(o.taken,"[]"),J(o.stats,"{}"),B(o.hidden),S(o.createdAt)]);
    for (const o of root.shifts || []) await c.query(
      "INSERT INTO shifts (id,aanbieder_id,hub_id,datum,dagdeel,shifts_bekend,starttijd,bus_type,taak,status,overnemer_id,besluit_door_id,besluit_op,reden,fifo_warning,fifo_skipped_by,fifo_skipped_at,seq,aanbied_reden,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20)",
      [S(o.id),S(o.aanbiederId),S(o.hubId),S(o.datum),S(o.dagdeel),B(o.shiftsBekend),S(o.starttijd),S(o.busType),S(o.taak),S(o.status),S(o.overnemerId),S(o.besluitDoorId),S(o.besluitOp),S(o.reden),B(o.fifoWarning),S(o.fifoSkippedBy),S(o.fifoSkippedAt),N(o.seq),S(o.aanbiedReden),S(o.createdAt)]);
    for (const o of root.taskOffers || []) await c.query(
      "INSERT INTO task_offers (id,aanbieder_id,hub_id,datum,dagdeel,taak,starttijd,aanbied_reden,status,overnemer_id,besluit_door_id,besluit_op,reden,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)",
      [S(o.id),S(o.aanbiederId),S(o.hubId),S(o.datum),S(o.dagdeel),S(o.taak),S(o.starttijd),S(o.aanbiedReden),S(o.status),S(o.overnemerId),S(o.besluitDoorId),S(o.besluitOp),S(o.reden),S(o.createdAt)]);
    for (const o of root.backups || []) await c.query(
      "INSERT INTO backups (id,aanbieder_id,hub_id,datum,dagdeel,direction,toelichting,rit_omschrijving,rit_tijd,status,overnemer_id,besluit_door_id,besluit_op,reden,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)",
      [S(o.id),S(o.aanbiederId),S(o.hubId),S(o.datum),S(o.dagdeel),S(o.direction),S(o.toelichting),S(o.ritOmschrijving),S(o.ritTijd),S(o.status),S(o.overnemerId),S(o.besluitDoorId),S(o.besluitOp),S(o.reden),S(o.createdAt)]);
    for (const o of root.callouts || []) await c.query(
      "INSERT INTO callouts (id,aanbieder_id,hub_id,datum,dagdeel,toelichting,status,overnemer_id,besluit_door_id,besluit_op,reden,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)",
      [S(o.id),S(o.aanbiederId),S(o.hubId),S(o.datum),S(o.dagdeel),S(o.toelichting),S(o.status),S(o.overnemerId),S(o.besluitDoorId),S(o.besluitOp),S(o.reden),S(o.createdAt)]);
    for (const o of root.logs || []) await c.query(
      "INSERT INTO logs (id,type,actie,ref_id,door_id,aanbieder_id,overnemer_id,hub_id,details,reden,ts) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,$10,$11)",
      [S(o.id),S(o.type),S(o.actie),S(o.refId),S(o.doorId),S(o.aanbiederId),S(o.overnemerId),S(o.hubId),J(o.details,"{}"),S(o.reden),S(o.timestamp)]);
    for (const o of root.plannings || []) await c.query(
      "INSERT INTO plannings (id,hub_id,week_start,created_at,rows,cells) VALUES ($1,$2,$3,$4,$5::jsonb,$6::jsonb)",
      [S(o.id),S(o.hubId),S(o.weekStart),S(o.createdAt),J(o.rows,"[]"),J(o.cells,"{}")]);
    const km = (k) => k.split("|"); // [hub,datum,dagdeel]
    for (const [k, o] of Object.entries(root.schade || {})) { const p = km(k); await c.query("INSERT INTO schade (hub_id,datum,dagdeel,buses,steekproeven) VALUES ($1,$2,$3,$4::jsonb,$5::jsonb)", [p[0],p[1],p[2],J(o.buses,"[]"),J(o.steekproeven,"[]")]); }
    for (const [k, o] of Object.entries(root.kwaliteit || {})) { const p = km(k); await c.query("INSERT INTO kwaliteit (hub_id,datum,dagdeel,emballage,soort) VALUES ($1,$2,$3,$4::jsonb,$5::jsonb)", [p[0],p[1],p[2],J(o.emballage,"{}"),J(o.soort,"{}")]); }
    for (const [k, o] of Object.entries(root.lc || {})) { const p = km(k); await c.query("INSERT INTO lc (hub_id,datum,dagdeel,aantal,vakken) VALUES ($1,$2,$3,$4,$5::jsonb)", [p[0],p[1],p[2],I(o.aantal),J(o.vakken,"[]")]); }
    for (const [k, o] of Object.entries(root.trolley || {})) { const p = km(k); await c.query("INSERT INTO trolley (hub_id,datum,dagdeel,stock4,stock5,pendels) VALUES ($1,$2,$3,$4,$5,$6::jsonb)", [p[0],p[1],p[2],I(o.stock4),I(o.stock5),J(o.pendels,"[]")]); }
    for (const [k, o] of Object.entries(root.diensten || {})) { const p = km(k); await c.query("INSERT INTO diensten (hub_id,datum,dagdeel,schadecontrole,lc,kwaliteit) VALUES ($1,$2,$3,$4::jsonb,$5::jsonb,$6::jsonb)", [p[0],p[1],p[2],J(o.schadecontrole,"[]"),J(o.lc,"[]"),J(o.kwaliteit,"[]")]); }
    if (root._seq != null) await c.query("INSERT INTO meta (k,v) VALUES ('_seq',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v", [String(root._seq)]);
    if (root.version != null) await c.query("INSERT INTO meta (k,v) VALUES ('appversion',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v", [String(root.version)]);
    await c.query("INSERT INTO meta (k,v) VALUES ('rev','1') ON CONFLICT (k) DO UPDATE SET v=(meta.v::bigint+1)::text");
    await c.query("COMMIT");
  } catch (e) { await c.query("ROLLBACK"); throw e; }
}

export async function handler(event) {
  const headers = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET,PUT,OPTIONS", "Access-Control-Allow-Headers": "Content-Type", "Content-Type": "application/json" };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers };
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await client.connect();
    await ensureSchema(client);
    if (event.httpMethod === "GET") {
      const has = (await client.query("SELECT 1 FROM users LIMIT 1")).rows.length > 0;
      if (!has) return { statusCode: 200, headers, body: JSON.stringify({ empty: true, version: 0 }) };
      const data = await buildState(client);
      const rev = (await client.query("SELECT v FROM meta WHERE k='rev'")).rows[0];
      return { statusCode: 200, headers, body: JSON.stringify({ version: rev ? Number(rev.v) : 0, data }) };
    }
    if (event.httpMethod === "PUT") {
      const root = JSON.parse(event.body || "{}");
      await saveState(client, root);
      const rev = (await client.query("SELECT v FROM meta WHERE k='rev'")).rows[0];
      return { statusCode: 200, headers, body: JSON.stringify({ version: rev ? Number(rev.v) : 0 }) };
    }
    return { statusCode: 405, headers, body: JSON.stringify({ error: "method" }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: String(e.message || e) }) };
  } finally { try { await client.end(); } catch (_) {} }
}
